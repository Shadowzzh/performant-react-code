export namespace PageInfo {
  /** 国家信息 */
  export interface Country {
    name: string
  }
}
